/*
 * Header file for sample (but incorrect) draw1.c.  Thus not a correct
 * header file for Assignment 1 (e.g., yours needs to have more
 * declarations).
 *
 * Style is not necessarily the style required for Assignment 1.
 */

#ifndef DRAW1_H
#define DRAW1_H


/* once we have functions in draw0.c we should have prototypes here */

#endif
