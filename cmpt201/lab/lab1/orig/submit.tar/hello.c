/*
 * A sample C program for use during the tar presentation.
 *
 * Will not work for Assignments.
 *
 * Prints out "howdy!".
 */
#include <stdio.h>
#include "hello.h"

int main(int argc, char* argv[])
{
  printf("howdy!\n");
  return 0;
}
