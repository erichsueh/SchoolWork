import java.awt.*;

interface Drawable
 {
  public void draw(Graphics graphicsIn);

 }
