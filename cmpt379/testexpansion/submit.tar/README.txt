Eric Hsueh
1384955

run make to compile a1shell.c
use the command ./a1shell (interval) to run the program
the rest is pretty self explanitory
