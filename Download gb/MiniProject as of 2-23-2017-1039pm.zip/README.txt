Seth Bergen
Eric Hsueh

TODO